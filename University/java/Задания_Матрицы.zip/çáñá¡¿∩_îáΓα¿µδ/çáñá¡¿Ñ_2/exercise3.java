import java.util.Arrays;
import java.util.Scanner;
import java.io.*;

public class Main
{
	
	public static void printMatrix(int a [] [])
	{
		for(int i = 0;i < a.length;i++)
		{
			for (int j = 0;j < a[i].length;j++)
				System.out.print(a[i][j] + " ");
			System.out.println();
		}
		
	}
	 public static void main(String[] args)
	 {
		 try
		 {
			 Scanner sc2 = new Scanner(System.in);
			 System.out.println("String number: ");
			 int str = sc2.nextInt();
			 System.out.println("Collumns number: ");
			 int stolb = sc2.nextInt();
			 int lengths[] = new int[str];
			 int [][] Matrix1 = new int[str][stolb];
			 int numb = 1;
			 int i = 0;
			 int j = 0;
			 int k1 = 1;
			 int k2 = 1;
			 int razmer = str*stolb;
			 while (numb <= razmer)
			 {
			    while((j < stolb-1) && (numb <= razmer))
			    {
			        Matrix1[i][j] = numb;
			        numb++;
			        j++;
			    }
			    stolb--;
			    while(( i < str-1) && (numb <= razmer))
			    {
			        Matrix1[i][j] = numb;
			        numb++;
			        i++;
			    }
			    str--;
			    k2++;
			    while((j>=0+k1) && (numb <= razmer))
			    {
			        Matrix1[i][j] = numb;
			        numb++;
			        j--;
			    }
			    k1++;
			    while((i>=0+k2) && (numb <= razmer))
			    {
			        Matrix1[i][j] = numb;
			        numb++;
			        i--;
			    }
			 }
			 System.out.println("matrix1:");
			 printMatrix(Matrix1);
			 PrintStream pw = new PrintStream("output.txt");
			 for(int i2 = 0; i2 < Matrix1.length; i2++)
		     {
			    for (int j2 = 0;j2 < Matrix1[i2].length;j2++)
				pw.print(Matrix1[i2][j2] + " ");
			    pw.println();
		     }
			 pw.close();
		 }
		 catch(IOException e)
			 {
				 System.out.println("Cannot find file!");
			 }
	 }
}