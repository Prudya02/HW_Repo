import java.util.Arrays;
import java.util.Scanner;
import java.io.*;

public class Main
{
	
	public static void printMatrix(int a [] [])
	{
		for(int i = 0;i < a.length;i++)
		{
			for (int j = 0;j < a[i].length;j++)
				System.out.print(a[i][j] + " ");
			System.out.println();
		}
	}
	 public static void main(String[] args)
	 {
		 try
		 {
			 FileInputStream  ifr = new FileInputStream("input.txt");
			 Scanner sc = new Scanner(ifr);
			 Scanner sc2 = new Scanner(System.in);
			 int counter1;
			 int counter2=0;
			 int k = 0;
	 		 PrintStream pw = new PrintStream("output.txt");
			 boolean isEnable = false;
			 int []ind1 = new int[6];
			 int enable_ind1 = 0;
			 int enable_ind2 = 0;
			 int Stolb_ind2 = -1;
			 int Stolb_ind1 = -1;
			 int []buffer = new int[6];
			 int [][] Matrix1 = new int[6][6];
			 for(int i = 0; i < 6; i++)
				 for(int j = 0; j < 6; j++)
					 Matrix1[i][j] = sc.nextInt();
			 System.out.println("matrix1:");
			 printMatrix(Matrix1);
			 for(int i = 0; i < 5; i++)
			 {
			     if (isEnable == false)
			     {
			        k = 0;
			        counter1 = 0;
				    for(int j = 0; j < 6; j++)
				    {
				        if (Matrix1[i][j] == 1)
				        {
				            enable_ind1 = i;
				            ind1[k]=j;
				            k++;
				            counter1++;
				        }
				    }
				    if ((counter1 > 1)&&(isEnable == false))
				    {
				       for (int p1 = i+1; p1 < 6; p1++)
				       {
				           if (isEnable == false)
				           {
				                counter2 = 0;
				                for ( int p2 = 0; p2 < k; p2++)
				                {
				                    if (Matrix1[p1][ind1[p2]] == 1)
				                    counter2++;
				                }
				                if (counter2>1)
				                {    
				                    enable_ind2 = p1;
				                    isEnable = true;
				                    System.out.println("We can get '1' square :) ");
				                    System.out.println("We will use strings № "+ enable_ind1+" and № "+ enable_ind2+" here");
				                }
				           }
				       }
				    }  
				}
			 } 
			 if (isEnable == false)
			 {
			     System.out.println("We can't get '1' square :( ");
			     pw.println("We can't get '1' square :( ");
			 }
			 else
			 {
			     for(int p3 = 0; p3 < 6; p3++)
			     {
			         if (enable_ind1!=2)
			         {
			             buffer[p3] = Matrix1[2][p3];
			             Matrix1[2][p3] = Matrix1[enable_ind1][p3];
			             Matrix1[enable_ind1][p3] = buffer[p3];
			         }
			         if (enable_ind2!=3)
			         {
			             buffer[p3] = Matrix1[3][p3];
			             Matrix1[3][p3] = Matrix1[enable_ind2][p3];
			             Matrix1[enable_ind2][p3] = buffer[p3];  
			         }
			     }
			     System.out.println("Matrix with string on their places:");
			     printMatrix(Matrix1);
			     for (int p4 = 0; p4 <6; p4++)
			     {
			         if ((Matrix1[2][p4] == 1) && (Matrix1[3][p4] == 1))
			         {
			             Stolb_ind2 = p4;
			         }
			         if (Stolb_ind1 == -1)
			            Stolb_ind1 = Stolb_ind2;
			     }
			     for(int p5 = 0; p5 < 6; p5++)
			     {
			         if (Stolb_ind1!=2)
			         {
			             buffer[p5] = Matrix1[p5][2];
			             Matrix1[p5][2] = Matrix1[p5][Stolb_ind1];
			             Matrix1[p5][Stolb_ind1] = buffer[p5];
			         }
			         if (Stolb_ind2!=3)
			         {
			             buffer[p5] = Matrix1[p5][3];
			             Matrix1[p5][3] = Matrix1[p5][Stolb_ind2];
			             Matrix1[p5][Stolb_ind2] = buffer[p5]; 
			         }
			     }
			     System.out.println("We will use stolbs № "+ Stolb_ind1+" and № "+ Stolb_ind2+" here");
			     System.out.println("Matrix with square of '1' :");
			     printMatrix(Matrix1);
			 }
			 pw.println("The Matrix with '1' square:");
	 		 for(int p7 = 0;p7 < Matrix1.length;p7++)
		    	 {
			    for (int j3 = 0;j3 < Matrix1[p7].length;j3++)
				pw.print(Matrix1[p7][j3] + " ");
			    pw.println();
		    	 }
 			 ifr.close();
			 pw.close();
		 }
		 catch(IOException e)
			 {
				 System.out.println("Cannot find file!");
			 }
	 }
}