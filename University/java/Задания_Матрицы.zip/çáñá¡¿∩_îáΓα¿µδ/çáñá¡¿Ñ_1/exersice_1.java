import java.util.Arrays;
import java.util.Scanner;
import java.io.*;

public class Main
{
	
	public static void printMatrix(int a [] [])
	{
		for(int i = 0;i < a.length;i++)
		{
			for (int j = 0;j < a[i].length;j++)
				System.out.print(a[i][j] + " ");
			System.out.println();
		}
		
	}
	 public static void main(String[] args)
	 {
		 try
		 {
			 FileInputStream  ifr = new FileInputStream("input.txt");
			 Scanner sc = new Scanner(ifr);
			 Scanner sc2 = new Scanner(System.in);
			 System.out.println("String number: ");
			 int str = sc2.nextInt();
			 System.out.println("Collumns number: ");
			 int stolb = sc2.nextInt();
			 int a1[] = new int[stolb];
			 int lengths[] = new int[str];
			 int max_str = 0;
			 int length = 0;
			 int [][] Matrix1 = new int[str][stolb];
			 for(int i = 0; i < str; i++)
				 for(int j = 0; j < stolb; j++)
					 Matrix1[i][j] = sc.nextInt();
			 System.out.println("matrix1:");
			 printMatrix(Matrix1);
			  for(int i = 0; i < str; i++)
			  {
				 for(int j = 0; j < stolb-1; j++)
				 {
				     length = 1;
				     while (Matrix1[i][j]==Matrix1[i][j+1])
				     {
				        length++;
				        j++;
				     }
				     if (length>lengths[i])
				     lengths[i]=length;
				 }
			  }
			 for(int i = 0; i < str; i++)
			 {
			    if (lengths[i]>max_str)
			        max_str = i;
			 }
			 PrintStream pw = new PrintStream("output.txt");
			 pw.println("String Index:" + max_str);
			 pw.println("Sequence length:" + lengths[max_str]);
			 ifr.close();
			 pw.close();
		 }
		 catch(IOException e)
			 {
				 System.out.println("Cannot find file!");
			 }
	 }
}