import java.io.*;
import java.util.*;

public class Main
{
	public static void main(String[] args) 
	throws IOException
	{
	    InputStreamReader isr = new InputStreamReader(System.in);
	    BufferedReader br = new BufferedReader(isr);
	    System.out.println("Input String:");
	    String str = br.readLine();
	    boolean unik = true;
	    int count = 0;
	    char []uniks = new char[str.length()];
	    for (int i = 0; i < str.length();i++)
	    {
	      unik = true;
	       for (int j = 0; j<str.length();j++)
	       {
	           if ((str.charAt(i) == str.charAt(j))&&(i!=j))
	               unik = false;
	       }
	       if (unik == true)
	       {
	        uniks[count]=str.charAt(i);
	        count ++;
	       }
	    }
	    System.out.println("Number of unik numbers: " + count);
	    for (int i = 0; i < count; i++)
	        System.out.print(uniks[i]);
	}
	
}