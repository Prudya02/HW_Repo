import java.io.*;
import java.util.*;

public class Main
{
    public static boolean isNumb(String str) 
    {
         int i = 0;
         char ch = str.charAt(i);
         if (ch == '-')
            if (str.length() == 1)
                return false;
            else
                i++;
         while (i<str.length())
         {
             ch = str.charAt(i);
             if ((ch <= '0') || (ch >= '9'))
                 return false;
             i++;
         }
         return true;
    }
    public static void main(String[] args) throws IOException 
    {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr); 
        System.out.println("Input string:");
        String str = br.readLine();	
        StringTokenizer st = new StringTokenizer(str,"\t\n\r,.:;?! ");
        String sr;
        int sum = 0;
	int i = 1;
        while (st.hasMoreTokens())	
        {
            sr = st.nextToken();
            if (isNumb(sr) == true)
            {
                System.out.println("numb["+i+"] = " + sr);
                sum += Integer.parseInt(sr); 
		i++;
            }
        }
        System.out.println("sum = " + sum);
    }
}