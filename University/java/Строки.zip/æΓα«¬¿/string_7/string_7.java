import java.util.Scanner;
import java.io.*;
import java.util.Arrays;
import java.util.Comparator;
    
public class Main
{
    public static void main(String[] args) throws IOException
    {
        FileInputStream ifr = new FileInputStream("input.txt");
        Scanner sr = new Scanner (ifr);
        String Buffer;
        PrintStream pw = new PrintStream("output.txt");
        StringBuffer sb = new StringBuffer();
        while (sr.hasNext())
        {
            String str = sr.nextLine(); 
            String[] ar = str.split(" ");
            int length = ar.length;
            Buffer = ar[length/2-1];
            ar[length/2-1] = ar[length/2];
            ar[length/2] = Buffer;
            int k = 0;
            for (String a : ar)
            {
				k++;
		        sb.append(a+ " "); 
            }
            if(k != 0)
            {
                pw.println(sb.toString().trim());
                sb.delete(0, sb.length()-1);
            }
        }
        ifr.close();
        pw.close();
    }
}