import java.util.Scanner;
import java.io.*;
import java.util.Arrays;
import java.util.Comparator;
    
public class Main
{
    public static void main(String[] args) throws IOException
    {
        FileInputStream ifr = new FileInputStream("input.txt");
        Scanner sr = new Scanner (ifr);
        PrintStream pw = new PrintStream("output.txt");
        StringBuffer sb = new StringBuffer();
        while (sr.hasNext())
        {
            String str = sr.nextLine(); 
            String[] ar = str.split(" ");
            
            Arrays.sort(ar, new StringSort());
            int k = 0;
            for (String a : ar)
            {
				k++;
		        sb.append(a+ " "); 
            }
            if(k != 0)
            {
                pw.println(sb.toString().trim());
                sb.delete(0, sb.length()-1);
            }
        }
        ifr.close();
        pw.close();
    }
}
class StringSort implements Comparator <String>
    {
        public int compare(String s1, String s2)
        {
         int t1 = glasNumb(s1);
         int t2 = glasNumb(s2);
         if (t1 == t2)
            return 0;
         if (t1 > t2)
            return 1;
         return -1;
        }
        public int glasNumb(String s)
        {
            int count = 0;
            String a = "auyioe";
            for (int i = 0; i < s.length();i++)
                for (int j = 0; j < 6; j++)
                    if (s.charAt(i) == a.charAt(j))
                        count++;
            return count;
        }
    }