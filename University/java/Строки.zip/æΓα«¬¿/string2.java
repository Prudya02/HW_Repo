import java.io.*;
import java.util.*;

public class Main
{
	public static void main(String[] args) 
	throws IOException
	{
	    InputStreamReader isr = new InputStreamReader(System.in);
	    BufferedReader br = new BufferedReader(isr);
	    System.out.println("Input String:");
	    String str = br.readLine();
	    boolean unik = true;
	    int pal_length = 0;
	    int max_pal_length=0 , max_pal_length2 = 0;
	    int k;
	    int ind_begin = 0, ind_begin2 = 0;
	    int ind_end = 0, ind_end2 = 0;
	    char []uniks = new char[str.length()];
	    for (int i = 1; i < str.length()-1;i++)
	    {
	        //АЛГОРИТМ ДЛЯ ПОИСКА НЕЧЕТНЫХ ПАЛИНДРОМОВ.
	       k=1;
	       if (str.charAt(i-1)==str.charAt(i+1))
	       {
	           pal_length = 1;
	           while ((str.charAt(i-k)==str.charAt(i+k))&&(k+1<=i)&&(i+k+1 < str.length()))
	           {
	               k=k+1;
	               pal_length = pal_length+2;
	               /* System.out.println("i=: " + i);
	                System.out.println("length =: " + pal_length);
	                System.out.println("k =: " + k);*/
	           }
	           if (str.charAt(i-k)==str.charAt(i+k))
                   pal_length = pal_length+2;
	           if (max_pal_length < pal_length)
	           {
	               max_pal_length = pal_length;
	               if (str.charAt(i-k)!=str.charAt(i+k))
	                   k--;
	               ind_begin = i-k;
	               ind_end = i+k+1;
	           }
	       }
	    }
	    String strMaxPalOdd = str.substring(ind_begin, ind_end);
	    System.out.println("Max Odd Palinom string: " + strMaxPalOdd + "(length = " + max_pal_length + ")");
	    
	    pal_length = 0;
	    for (int i = 0; i < str.length()-1;i++)
	    { 
	       //АЛГОРИТМ ДЛЯ ПОИСКА ЧЕТНЫХ ПАЛИНДРОМОВ
	       k=1;
	       if (str.charAt(i)==str.charAt(i+1))
	       {
	           pal_length = 0;
	           while ((str.charAt(i+1-k)==str.charAt(i+k))&&(k<=i)&&(i+k+1 < str.length()))
	           {
	               k=k+1;
	               pal_length = pal_length+2;
	               /* System.out.println("i=: " + i);
	                 System.out.println("length =: " + pal_length);*/
	           }
	           if (str.charAt(i-k+1)==str.charAt(i+k))
	               pal_length = pal_length+2;
	           if (max_pal_length2 < pal_length)
	           {
	               max_pal_length2 = pal_length;
	               if (str.charAt(i-k+1)!=str.charAt(i+k))
	                k--;
	               ind_begin2 = i+1-k;
	               ind_end2 = i+k+1;
	           }
	       }
	    }
	    //Ищу максимальный из четного и нечетного
	    String strMaxPalEven = str.substring(ind_begin2, ind_end2);
	    System.out.println("Max Even Palinom string: " + strMaxPalEven  + "(length = " + max_pal_length2 + ")");
	    if (max_pal_length2 > max_pal_length)
	    {
	        System.out.println("Max Palinom string: " + strMaxPalEven);
	        System.out.println("It's length:=" + max_pal_length2);
	    }
	    else 
	    {
	        System.out.println("Max Palinom string: " + strMaxPalOdd);
	        System.out.println("It's length:=" + max_pal_length);
	    }
	}
}

