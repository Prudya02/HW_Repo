import java.util.Scanner;
import java.io.*;
import java.util.Arrays;
import java.util.Comparator;


public class Main
{
    public static boolean isAwordA(String str)
    {
		if ((str.charAt(0)=='a') && (str.charAt(str.length()-1)=='a'))
            return true;
		return false;
    }
    public static void main(String[] args) throws IOException
    {
        FileInputStream ifr = new FileInputStream("input.txt");
        Scanner sr = new Scanner (ifr);
        PrintStream pw = new PrintStream("output.txt");
        StringBuffer sb = new StringBuffer();
        while (sr.hasNext())
        {
            String str = sr.nextLine(); // читает всю строку из файла
            String[] ar = str.split(" ");
            
            Arrays.sort(ar, new StringSort());
            int k = 0;
            for (String a : ar)
            {
			if (isAwordA(a))
			{
				k++;
				sb.append(a+ " ");  // сцепление слов в строку
			}
             }
             if(k != 0)
             {
                 pw.println("kol-vo slov = " + k);
                 pw.println(sb.toString().trim());
                 sb.delete(0, sb.length()-1);	// очищение строки
             }
        }
        ifr.close();
        pw.close();
    }
}
class StringSort implements Comparator <String>
    {
        public int compare(String s1, String s2)
        {
         return (s1.compareTo(s2));
        }
    }
    